# giftplatform
GIFT project platform

## API
https://gifting.digital/wp-json/wp/v2/gift

## Keys
https://console.developers.google.com/apis/credentials

## Stack
https://roots.io